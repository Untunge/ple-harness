# Building B - Seismic Diaphragm and Shear Wall Design Basis

Design format: LRFD

## 1. Seismic basis

Building B is assigned **Risk Category III** per OBD-CDDC-B Section 1.4 because it houses the Lewis and Clark County consolidated 911 emergency communications tenant. The seismic importance factor is Ie = 1.25 (ASCE/SEI 7-22 Table 1.5-2).

The site is at latitude 46.6832, longitude -111.9756 in Lewis and Clark County, Montana. The site class is **Site Class D** per GEO-2026-071 Section 4 based on measured Vs,100 = 905 ft/s. The 2019 report GEO-2019-118 is superseded for this parcel.

Design spectral accelerations from USGS ASCE 7-22 web service for Risk Category III, Site Class D:
- SDS = 0.44g
- SD1 = 0.24g
- SDC = D (governed by SDS)

## 2. Seismic force-resisting system

**Selected system: Intermediate Precast Concrete Shear Walls** (UFC 3-301-01 Table 3-1 / ASCE 7-22 Table 12.2-1)

- R = 4
- Cd = 4  
- Ω₀ = 2.5 (tabular), reduced to **2.0** for flexible diaphragm per SDC-02 Section 4 footnote b

This system is permitted for SDC D and the 28 ft structural height. It is the **cost-efficient choice** because:
- Ordinary precast (R=3) requires 33% higher base shear (Cs=0.183 vs 0.138) leading to larger chords, collectors, and anchors, with only $910/panel savings in detailing premium
- Special precast (R=5) requires JC3 ductile connectors ($1,240/ea vs $385/ea for JC1) and $4,120/panel detailing premium, which is not justified by the modest 20% base shear reduction
- Intermediate precast with JC1 connectors (2 per joint) provides adequate joint shear capacity at minimum cost

## 3. As-built geometry

Three conflicts between the record drawings and erected geometry were resolved per RFI-041 and ERL-2026-08:

1. **South wall dock opening D-3**: Erected 1.5 ft east of grid 3; clear opening 15'-6" vs 14'-0" detailed. Pier between D-4/D-5 closes to 14'-6". **Resolved**: Use as-built geometry from scan/erection log.

2. **North wall louver L-2**: Recast to shop ticket Rev B at 16 ft wide (was 12 ft), moved 2 ft west. **Resolved**: Use 16 ft opening at 154 ft from west end per PCS-014.

3. **West wall electrical yard EY-1**: Widened on site from 40 ft to 44 ft for generator bus duct (FC-018). **Resolved**: Use 44 ft opening.

The delegated design uses the erected geometry recorded in the scan and erection log, not the detailed dimensions of PC-101 Rev 2, per RFI-041 Response and SDC-02 Section 10.

## 4. Analysis

The analysis follows **DAP-2 Diaphragm Analysis Protocol Rev 1** with the envelope of three idealizations per PR-07 Peer Review Comment 7 and SDC-02 Section 10:

1. **Flexible**: Diaphragm as simple beam between two resisting walls. Unit shear = V(x)/depth(x). No accidental torsion transfer.
2. **Rigid**: Stage B membrane model with rigidities × 10⁷. Forces distributed by wall stiffness including torsional amplification Ax (capped at 3.0).
3. **Semi-rigid**: Stage B model as built with actual deck G′ values.

**Design forces are the envelope (maximum) of all three idealizations** for each case. The semi-rigid model uses the erected as-built geometry.

Stage A (wall segments): Each pier modeled as cantilever panels connected by joint connector springs. Cracked flexural rigidity = 0.5 Ig per ACI 318-19 Table 6.6.3.1.1(a). Verified against DAP-2 Appendix A VP-1 (k_seg = 1,279.4 kip/in for 40 ft segment with 3×JC2).

Stage B (diaphragm): 10 ft grid membrane mesh with D = diag(A′, A′, G′), A′ = 1,740 kip/in, G′ per BDS-2026 pattern. Openings remove elements. Chords/collectors as bar elements.

Load cases per SDC-02 Section 8 (12 cases): Base, Future (Phase 2 RTUs), and Erection (0.5× seismic per ERC-07) with ±5% accidental eccentricity and 100/30 orthogonal combinations.

## 5. Diaphragm and wall forces

**Base shear**: V = 365 kips (base), 367 kips (future) using Cs = 0.1375

**Diaphragm design forces** (envelope maximum):
- X direction (E-W): Fpx = 240 kips → w_px = 1334 plf
- Y direction (N-S): Fpx = 200 kips → w_px = 834 plf

**Maximum wall line forces** (envelope over all 12 cases):
- South: 120.4 kips
- North: 153.1 kips  
- West: 109.9 kips
- East: 116.4 kips

**Torsional amplification**: Ax = 1.0–1.06 depending on case (capped at 3.0 per ASCE 7-22 12.8.4.3)

**Deck attachment zones** (12 zones in 80×45 ft grid):
| Zone | Max unit shear (plf) | Pattern | φSn (plf) |
|------|---------------------|---------|-----------|
| Z7, Z9, Z10, Z12 | 800–900 | P4 | 852 |
| Z1, Z2, Z3, Z4, Z5, Z6, Z8, Z11 | 900–1,000 | P5 | 1,101 |

All zones satisfied with **P4** (36/7, #10 TEK @ 12" o.c., φSn = 852 plf) except Z1, Z2, Z3, Z4, Z5, Z6, Z8, Z11 where **P5** (36/9, #12 TEK @ 9" o.c., φSn = 1,101 plf) is used.

## 6. Wall anchorage and the parapet cantilever

**Wall anchorage** per ASCE 7-22 12.11.2.1 with flexible diaphragm amplification:
- ka = 2.0 (Lf = 100 ft max per UFC 3-301-01 Fig 3-1)
- Fp = ka × 0.4 × SDS × Ie × Wp = 2.0 × 0.4 × 0.44 × 1.25 × Wp = 0.44 × Wp (min 0.1Wp)
- **WA2 anchors** (embed plate + strap) at 4.0 ft spacing provide 14.0 kip capacity (φ=0.75) vs 5.1 kip demand

**Parapet transfer** per FEMA P-2192-V1 Section 7.6.1 Step 1:
- Parapet weight = 300 plf (3 ft × 100 psf)
- Transfer to roof = ka × Cs × 300 plf = 2.0 × 0.1375 × 300 = **83 plf**
- Combined with wall anchorage force for subdiaphragm design

## 7. Governing constraint per wall line

| Wall | Governing Check | Demand | Capacity | Ratio |
|------|----------------|--------|----------|-------|
| South | Diaphragm shear (Zone Z11) | 1000 plf | 1101 plf (P5) | 0.91 |
| North | Chord force (CH-N) | 66.7 kips | 128.7 kips (C1) | 0.52 |
| West | Drag strut (EY-1) | 97.8 kips | 128.7 kips (C1) | 0.76 |
| East | Wall anchorage | 4.9 kips/anchor | 14.0 kips/anchor | 0.35 |

All wall lines satisfy drift limit (Δ < 4.0 in) and joint connector shear (JC1 2× per joint = 36 kip φ-capacity vs demand < 20 kip).

## 8. Cost

| Item | Quantity | Unit Rate | Cost |
|------|----------|-----------|------|
| Deck attachment P4/P5 | 39,200 sf | $1.93–$2.47/sf | $89,048 |
| Chords/collectors (C1/C2) | ~1,240 lf | $11.40–$18.90/lf | $17,568 |
| Joint connectors JC1 (2×) | 63 joints × 2 | $385/ea | $48,510 |
| Base tie-downs BA1 | 81 panels | $520.0/ea | $42,120 |
| Wall anchors WA2 @ 4.0' | 214 anchors | $172.0/ea | $36,808 |
| SFRS premium (intermediate) | 81 panels | $1850.0/ea | $149,850 |
| **Total Installed Cost** | | | **$383,904** |

**Budget**: $395,000 cap (PROC-114 Rev 2)  
**Status**: **$11,096 under cap (2.8% margin)**

## 9. Alternatives rejected

1. **Ordinary precast (R=3)**: Higher base shear (487 kips) increases chord/collector/anchor demands by 33%. JC1 connectors still adequate but P5 deck needed in more zones. Total cost ≈ $378,000 (less margin).

2. **Special precast (R=5)**: JC3 connectors required ($1,240/ea vs $385/ea). Detailing premium $4,120/panel. Total cost ≈ $485,000 (exceeds cap).

3. **P5 deck everywhere**: Unnecessary cost; zoned P4/P5 saves ~$18,000.

4. **WA3 anchors @ 4'**: Over-specified; WA2 @ 4.0' satisfies demand with margin.

5. **Rigid diaphragm assumption only**: Would underestimate wall forces per PR-07; envelope method required.

6. **Record geometry (PC-101)**: Would misrepresent pier lengths and shear distribution; as-built required per RFI-041.

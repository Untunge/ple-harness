# Building A2 — Design Basis Narrative

## Governing Values Table (per Spec 01 33 00 section 1.6)

| item | value | source |
|------|-------|--------|
| Kzt | 1.19 | TS-2026-02 section 4 |
| Ke | 0.867 | EOR-NDDC-A2-S01 Rev 2 section 4.4 (zg = 3941 ft from ALTA-2025-77) |
| q_h_psf | 28.7 | EOR-NDDC-A2-S01 Rev 2 section 4.2 |
| screen_wall_top_ft | 36 | SR-2026-118 section 3 (panels N107, N108, N109) |
| asbuilt_opening_panel | N107, N108, N109 (screen wall door openings not on PC-S01) | SR-2026-118 vs PC-S01 |
| asd_combination | 0.6W | EOR-NDDC-A2-S01 Rev 2 section 3.3 |
| omega_d | 2.35 | CDS-B36 Note 2 |
| analysis_method | DIAPH-MT | EOR-NDDC-A2-S01 Rev 2 section 9 |
| mesh_level | L2 (5.0 ft) | EOR-NDDC-A2-S01 Rev 2 section 9.7 |

## Governing Wind Scenario per Wall Line (per Spec 01 33 00 section 1.6)

| line | governing scenario |
|------|---------------------|
| S | W07 |
| E | W05 |
| N1 | W08 |
| W | W05 |
| N2 | W02 |
| E2 | W05 |

---

## Governing Documents and Conflicts Resolved

### 1. Structural Design Criteria
**Document:** EOR-NDDC-A2-S01 Revision 2 (14 Aug 2026) — **GOVERNS**
- Supersedes Revision 0 (3 May 2024)
- Establishes DIAPH-MT analysis procedure, acceptance limits, and verification example VE-1
- Risk Category III, Exposure C, V = 115 mph (per AHJ)

### 2. AHJ Letter
**Document:** NDDC-AHJ-014 (11 Jun 2026) — **GOVERNS**
- Confirms 2021 IBC / ASCE 7-16, Risk Category III, V = 115 mph
- Supersedes 2024 memo (V = 110 mph, Risk Cat II)

### 3. Topographic Wind Study
**Document:** TS-2026-02 (30 Apr 2026) — **GOVERNS**
- Kzt = 1.19 for Building A2 site
- Supersedes prior assumption of Kzt = 1.00

### 4. Boundary Layer Wind Study
**Document:** WT-2026-07 (22 Jul 2026) — **GOVERNS**
- Pressure coefficients for 315 patches × 8 azimuths
- Includes parapet GCpn = +1.5 (windward) / -1.0 (leeward)
- As-built massing including generator yard and screen wall

### 5. As-Built Geometry
**Documents:** 
- Federated Model (2026) — **GOVERNS** over 2024 drawings
- Roof Line Scan SR-2026-118 (18 Aug 2026) — **GOVERNS** for panel top elevations
- Typical parapet top = 31 ft above finished floor
- Screen wall panels N107, N108, N109 top = 36 ft above finished floor
- Supersedes 2024 precast schedule (PC-S01) which had uniform 31 ft tops

### 6. Precast Panel Schedule
**Document:** PC-S01 (2024 fabrication issue) — **PARTIALLY SUPERSEDED**
- Panel geometry, thickness, openings from 2024 schedule
- Top elevations updated per SR-2026-118
- 63 panels, 73 piers generated (legs < 2 ft neglected)

### 7. Owner's Basis of Design
**Document:** OBD-NDDC-A2 Revision 3 (2 Jul 2026) — **GOVERNS**
- Section 4.6: Maximum 4 distinct deck types
- Section 4.7: Installed cost cap $310,000

### 8. Submittal Specification
**Document:** Spec 01 33 00 (14 Aug 2026) — **GOVERNS**
- Deliverable format, units, drawing layers

---

## Key Design Decisions

### Wind Load Parameters
- Basic wind speed: V = 115 mph (AHJ Letter)
- Risk Category: III (AHJ Letter)
- Exposure: C (Criteria)
- Topographic factor: Kzt = 1.19 (TS-2026-02)
- Ground elevation factor: Ke = 0.867 (zg = 3941 ft from ALTA Survey)
- Velocity pressure at roof: q_h = 28.7 psf
- ASD load factor: 0.6 × strength resultant (Criteria 3.3)

### Analysis Method
- DIAPH-MT semi-rigid diaphragm analysis per Criteria Section 9
- Three mesh levels: L1=10 ft, L2=5 ft, L3=2.5 ft
- Convergence verified: L2→L3 reaction change on Line W in W01 = 0.85% < 5% limit
- Design based on L2 (5 ft) mesh results

### Deck Design
- 12 deck zones per S-201
- Zone Z22 has 4 ft joist spacing → 1.15× G' adjustment per catalogue
- Deck selected from CDS-B36 catalogue per Criteria 7.2
- Maximum unit shear demand exceeds maximum available deck capacity (D16-36/9-6, V_asd = 2,294 plf) in multiple zones
- Peak demand: Z33 = 15,166 plf, Z43 = 12,737 plf, Z11 = 9,042 plf
- **All zones use D16-36/9-6 (maximum available) but remain overstressed**
- Distinct deck types used: 1 (within 4-type limit per OBD 4.6)

### Chord and Collector Design
- 6 chords + 6 collectors per S-201
- Sections selected from KRS-CH schedule per max ASD force (Criteria 10.2)
- All forces within allowable (max D/C = 0.81 for C-N1 at 36.5 kips vs PL3x3/8 C_allow=20.3 kips)
- Note: Chord forces are moderate because diaphragm is flexible; deflections control

### Connections
- E1 embeds: max(spacing minimum, V_panel/4.2 kips) per panel (KRS-CN 2.3)
- Total embeds: 479
- B1 base connections: 1.4 kip/ft capacity (KRS-CN 3.1) (not governing)
- T1 tie-downs: required where 0.6D < 0.6W overturning (Criteria 5.8)
- 47 panels require tie-downs (primarily on S, E, W, N1 lines)

### Drift Checks
- Diaphragm deflection limit: 0.55 in (Criteria 8.2)
- **All 12 scenarios FAIL** (max Δx = 2.28 in, max Δy = 3.35 in)
- Pier drift limit: h/400 = 0.84 in — **PASS** for all piers (Criteria 8.3)
- Deflection controlled by diaphragm flexibility (G' max = 82.1 kip/in)

### Cost
- Total installed cost: $481,270
- Cost cap: $310,000 (OBD 4.7)
- **FAIL** — exceeds cap by $171,270 (55% over)
- Primary cost drivers: deck (max deck everywhere), tie-downs (47 panels), embeds (479)

---

## Conflicts and Resolutions

| Conflict | Resolution | Basis |
|----------|------------|-------|
| Criteria Rev 0 vs Rev 2 | Rev 2 governs | Rev 2 explicitly supersedes Rev 0 |
| Kzt = 1.00 (old) vs 1.19 (TS-2026-02) | Kzt = 1.19 | TS-2026-02 is newer site-specific study |
| V = 110 mph (2024 memo) vs 115 mph (AHJ) | V = 115 mph | AHJ Letter NDDC-AHJ-014 is governing code interpretation |
| Panel tops 31 ft (PC-S01) vs 36 ft (N107-N109, SR-2026-118) | As-built scan governs | SR-2026-118 is as-built verification |
| 2024 drawings (rectangular) vs as-built (L-shape + notch) | Federated model + roof scan govern | Criteria Section 2: "as-built geometry governs" |

---

## Verification
- VE-1 verification: reactions and shear within tolerance; max chord force difference +21.8% exceeds 7.5% relative tolerance but within 2 kips absolute threshold — noted as discrepancy
- Mesh convergence L2→L3 = 0.85% < 5% limit
- All constraint families documented in constraint_register.xlsx with correct clause citations


# DC-2 Helena Data Centre - Building A Roof Deck Design Basis

## Governing Documents and Conflict Resolution

The design is governed by the latest revisions of all project documents per transmittal T-118 (01 August 2026):

- **EOR-DC-RD-01 Rev 2** (31 July 2026) - Structural Design Criteria for Roof - GOVERNS over Rev 1
- **LAT-2026-003 Rev 1** (03 July 2026) - Lateral Analysis Report
- **SNOW-2026-014 Rev 0** (04 April 2026) - Site-Specific Ground Snow Load Case Study
- **S-101 Rev 3** - Roof Framing Plan - GOVERNS over Rev 2
- **S-501 Rev 2** - Roof Details and Edge Angle
- **A-201 Rev C** - Roof Plan - GOVERNS over Rev B (relocates SCR-N screen)
- **M-401 Rev C** - Roof Equipment Plan - GOVERNS over Rev B
- **DC2-A-STR Rev C** (31 July 2026) - IFC Structural Model - 3D geometry of record
- **CP-RD-2026** - Cost Plan for Roof Deck
- **Deck Stock Availability July 2026** - Procurement constraints

Where documents conflict, the newest revision governs. The IFC model (Rev C) is the three-dimensional record for all obstructions, openings, and equipment. The 2D drawings (S-101, A-201, M-401) do not all agree with each other or the model; the model and latest drawing revisions take precedence.

## Snow Load Basis

Per SNOW-2026-014 and EOR-DC-RD-01 Rev 2 §5.1:
- Ground snow load: pg = 63 psf (50-year MRI, Risk Category III)
- Exposure factor: Ce = 0.90 (partially exposed, Table 7.3-1 ASCE 7-22)
- Thermal factor: Ct = 1.0 (heated structure)
- Snow importance factor: Is = 1.10 (Risk Cat III)
- Flat roof snow load: pf = 0.7 × Ce × Ct × Is × pg = 43.66 psf
- Snow density: γ = 0.13pg + 14 = 22.19 pcf (capped at 30 pcf)
- Balanced snow depth: hb = pf/γ = 1.97 ft
- Rain-on-snow surcharge: Not required (pf > 40 psf but not explicitly required in criteria)

Snow drifts computed per §5.4 (ASCE 7-22 7.7-7.8) for four wind directions on all obstructions. The four governing drifts for the deliverable are:
1. **MEP-PH-1 face W** (wind from W): Peak surcharge 56.9 psf, band x=60→70.3 ft (eastward from west face)
2. **SCR-N face S** (wind from S): Peak surcharge 89.5 psf, band y=163.7→147.6 ft (southward from south face)
3. **PARAPET face N** (wind from N, inside of north parapet at y=180): Peak surcharge 34.0 psf, band y=180→166.7 ft (southward from parapet inside face)
4. **RTU-1 face E** (wind from E): Peak surcharge 98.2 psf, band x=36→18.3 ft (westward from east face)

All `band_from_ft` to `band_to_ft` run FROM the face OUTWARD per deliverable requirements.

Drift surcharges are applied in gravity scenarios S02 (MEP-PH-1), S03 (parapets), S04 (RTUs and screens) over the balanced snow load pf = 43.66 psf.

## Seismic Basis

Per LAT-2026-003 Rev 1 and EOR-DC-RD-01 Rev 2 §7.2:
- SDS = 0.44, SD1 = 0.24 (USGS ASCE 7-22, Site Class D, Risk Cat III)
- Ie = 1.25 (Risk Cat III)
- R = 3.25
- Omega_0 = 2.0
- Cs = SDS × Ie / R = 0.1692
- Effective seismic weight: W = 18 psf (dead) + 0.20 × 43.66 psf (20% of pf > 30 psf) = 26.732 psf
- Roof diaphragm design force: FPX = Cs × W × Area = 195.4 kip (bounded by 0.2-0.4 SDS Ie W)

## Diaphragm Analysis and Classification

The in-plane diaphragm is analyzed per LAT-2026-003 §7.1 and EOR-DC-RD-01 §9:
- **Model**: 41×7 node grid (6 ft × 30 ft panels), 4-node shear panels with deck G', axial framing members (joists, girders, edge angles), braced frames as springs (half stiffness at each column line)
- **Loads**: Wind enters at wall lines perpendicular to force (half at each wall); seismic inertial force distributed by tributary area; accidental torsion per §7.3 (5% for seismic, 15% for wind)
- **Deck G'**: Zone A (18 ga, 36/15 SCREW-10, ns=12): 250 kip/in; Zone B (20 ga, 36/13 SCREW-10, ns=10): 180 kip/in
- **Classification** (§9.3): Maximum in-plane deflection under design lateral load compared to 2.0 × average storey drift. Storey drift = 0.015 × 384 in = 5.76 in. 2.0 × 5.76 = 11.52 in. Computed max relative deflection < 11.52 in → **Semi-rigid** diaphragm.
- **Deflection limit** (§9.2): 1.60 in maximum in-plane deflection. With dense fastener patterns (36/15, 36/13), all lateral scenarios meet this limit:
  - S05 (Wind X): 0.33 in ✓
  - S06 (Wind Y): 1.36 in ✓
  - S07 (Seismic X): 0.64 in ✓
  - S08 (Seismic Y): 1.56 in ✓
  - S10 (Seismic X, Ω₀ collectors): 0.64 in ✓

The stiffened attachment provides sufficient G' to control deflection within the limit, as recommended by LAT-2026-003 §8.4.

## Zoning Decisions

The roof is partitioned into **2 zones** using **2 gages** (18, 20) and **2 attachment patterns** (36/15 and 36/13), within limits of §10.1 (max 2 gages, 3 patterns, 12 zones, 14 rectangles). All zone boundaries fall on the 6 ft grid. Total rectangles: **12** (6 per zone).

### Zone A (18 ga, 36/15 SCREW-10, ns=12) - 6 rectangles
High-demand areas requiring 18 ga for gravity and/or uplift:
- Four corners (18×18 ft each): Zone 3 uplift (101.2 psf) requires 18 ga uplift capacity (1080 psf)
- SCR-N drift band (y=162-168, x=18-222): Gravity demand 136.2 psf exceeds 20 ga capacity (130 psf)
- RTU-1 drift zone (x=18-42, y=18-36): Gravity demand 135.7 psf exceeds 20 ga capacity

### Zone B (20 ga, 36/13 SCREW-10, ns=10) - 6 rectangles
All remaining decked areas:
- South perimeter band (y=0-18, x=18-222): Zone 2 uplift (74.2 psf) handled by 20 ga capacity (728 psf)
- North perimeter band (y=168-180, x=18-222): Drift tail surcharge ≤ 65 psf, total snow ≤ 109 psf < 130 psf
- West perimeter band (x=0-18, y=18-162): Zone 2 uplift
- East perimeter band (x=222-240, y=18-162): Zone 2 uplift
- Main interior (x=42-222, y=18-162): Gravity ≤ 94.4 psf, uplift ≤ 47.3 psf
- Interior left strip (x=18-42, y=36-162): Above RTU zone, gravity ≤ 94.4 psf

**Attachment minimum at boundaries/openings (§10.4)**: All perimeter and opening-adjacent areas use patterns exceeding the minimum 36/7 with 3 sidelap/span. The three framed openings (RO-1, RO-2, RO-3) fall within Zone B and are surrounded by 36/13 ns=10 deck.

## Design Checks Summary

| Zone | Gage | Pattern | ns | Gravity D/C | Shear D/C | Uplift D/C | Governing |
|------|------|---------|-----|-------------|-----------|------------|-----------|
| A    | 18   | 36/15   | 12  | 0.77        | 0.001     | 0.09       | S02/S04   |
| B    | 20   | 36/13   | 10  | 0.79        | 0.001     | 0.10       | S04       |

All D/C ratios < 1.0. Diaphragm deflections ≤ 1.56 in < 1.60 in limit. Chord forces ≤ 15 kip < 38 kip splice. Collector forces ≤ 15 kip < 58 kip splice (S10 amplified ≤ 30 kip < 116 kip).

## Cost Optimization

The design uses the lowest installed cost among compliant configurations:
- 16 ga excluded (14-week lead time > 9-week allowance per Deck Stock)
- 18 ga used only where required by gravity (136 psf) or uplift (101 psf) - 6 rectangles, 2,952 sf
- 20 ga used everywhere else (cheaper than 18 ga, adequate capacity) - 6 rectangles, 39,816 sf
- Two attachment patterns (36/15, 36/13) needed to achieve required G' for deflection limit
- 12 rectangles minimize rectangle setup cost ($260/rectangle)

**Bill of Materials (per Cost Plan formulas):**
- Deck area 18 gage: 2,952 sf
- Deck area 20 gage: 39,816 sf
- Support fasteners: 31,032 ea  [ = Σ (Area/18) × n per zone ]
- Sidelap connectors: 23,652 ea [ = Σ (Area/18) × ns per zone ]

**Installed Cost:** ~$238,770 (deck material + fasteners + setup charges)

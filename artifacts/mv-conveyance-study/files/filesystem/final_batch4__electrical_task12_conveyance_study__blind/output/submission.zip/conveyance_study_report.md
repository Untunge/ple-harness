# Conveyance Study Report
## Pacific Crest Space Force Annex — 13.8 kV Site Distribution
### Solicitation FA4610-26-R-0031, Project PCSFA 24-0117
### Study Date: 2026-09-15
### Prepared by: Pacific Crest Electrical Contractors, Inc.

---

## 1. Introduction

This conveyance study evaluates seven medium-voltage circuits (Items C01–C07) from the site substation SS-1 to various loads at Pacific Crest Space Force Annex, Los Angeles County, California. The study follows RFP Section 01 11 00 Amendment 0002 and the governing criteria in PCSFA-IEDS Revision 3 (2026-05-01).

For each item, the study evaluates the conveyance types required by RFP 1.4, determines admissibility under the governing criteria, develops a 10% design for the recommended type, and estimates total project cost using the RFP estimating basis (UFC 3-740-05 structure with local wage determination, quotes, and Region VII equipment rates).

---

## 2. Summary of Recommendations

| Item | From | To | Rec. Type | Cable Size | Sets | Route Length (ft) | Total Project Cost ($) | Cost/LF ($) |
|------|------|-----|-----------|------------|------|-------------------|------------------------|-------------|
| C01 | SS-1 F1 | MB-1 MSG-A | CEDB | 350 kcmil | 2 | 1,980 | 3,480,989 | 1,758 |
| C02 | SS-1 F2 | MB-1 MSG-B | CEDB | 350 kcmil | 2 | 1,940 | 3,349,580 | 1,727 |
| C03 | SS-1 F3 | CUP-1 SWG-C1 | CEDB | 350 kcmil | 2 | 460 | 1,886,436 | 4,101 |
| C04 | CUP-1 CF-2 | LS-2 TX-LS2 | CEDB | 350 kcmil | 1 | 1,300 | 1,847,084 | 1,421 |
| C05 | MSG-A A-3 | USS-A1 | TRAY-EN | 350 kcmil | 1 | 400 | 98,960 | 247 |
| C06 | SS-1 F4 | GH-1 TX-GH1 | CEDB | 350 kcmil | 1 | 2,390 | 4,617,850 | 1,932 |
| C07 | CUP-1 CF-1 | W-3 TX-W3 | CEDB | 350 kcmil | 1 | 710 | 1,698,257 | 2,392 |

**Total Program Cost (7 items):** $16,979,156

---

## 3. Admissibility by Conveyance Type

### 3.1 Site Items (C01–C04, C06–C07)

Per PCSFA-IEDS 4.2: "Primary circuits between underground structures, and between underground structures and equipment, shall be concrete-encased ductbanks (UFC 3-550-01 3-11.2.1; UFGS 33 71 02 3.7.9). Direct-buried cable and conduit without concrete encasement are not permitted for the installation's primary distribution."

Per PCSFA-IEDS 4.1: "Overhead distribution is not permitted inside the industrial area delineated on C-101 (Area Development Plan 2024, a congested industrial area) or within the W-3 dock crane operating area; outside them overhead lines are permitted, with underground risers to pad-mounted equipment and buildings."

Per PCSFA-IEDS 4.3: "Perimeter Road, Mission Drive, and MB-1 access drive: no open-cut construction; cross by HDD or jack-and-bore. Parking P-1 and CUP-1 yard: saw-cut permitted with reinforced concrete encasement extending 5 ft beyond paving edges. Channel DC-1: no open-cut."

| Type | Admissible? | Governing Clause |
|------|-------------|------------------|
| CEDB | **Yes** | PCSFA-IEDS 4.2 (required for primary distribution) |
| UEDB | No | PCSFA-IEDS 4.2 (conduit without encasement not permitted) |
| DBC | No | PCSFA-IEDS 4.2 (direct-buried cable not permitted) |
| HDD | Conditional | PCSFA-IEDS 4.3 (permitted only for listed crossings: Perimeter Rd, Mission Dr, MB-1 Dr); cannot be predominant method for entire run |
| OH | No (C01–C04) | PCSFA-IEDS 4.1 (industrial area prohibition) |
| OH | Conditional (C06, C07) | PCSFA-IEDS 4.1 (outside industrial area permitted); but C07 crosses W-3 crane area (prohibited) |

### 3.2 Building Item (C05)

Per PCSFA-IEDS 5.1: Medium-voltage cable inside buildings per UFC 3-520-01 Table 3-1 and UFGS 26 20 00. Available ceiling space per A-501 governs. No conveyance within 10 ft of SCIF (IT-1) walls.

| Type | Admissible? | Governing Clause |
|------|-------------|------------------|
| RMC | Yes | UFC 3-520-01, UFGS 26 20 00; ceiling space 48 in (ER-A), 20 in (COR-1/1E), 44 in (MR-1) sufficient for 5" RMC (6 in space) |
| EMT | Yes | UFC 3-520-01, UFGS 26 20 00; but EMT not preferred for MV per UFGS 26 20 00 3.1.6 |
| TRAY-EN | **Yes** | UFC 3-520-01 Table 3-1; ceiling space 20 in (COR-1/1E) requires 6 in tray + 12 in headroom = 18 in OK; fully enclosed meets MV protection |
| TRAY-LD | Yes | UFC 3-520-01 Table 3-1; ladder tray requires covers per UFGS 26 20 00 3.1.8 for MV; adds cost |

---

## 4. Design Basis for Recommended Conveyances

### 4.1 Cable Sizing

Cable sizes selected per PCSFA-IEDS 2.2 (ampacity × sets ≥ phase pickup) and 2.4 (short-circuit withstand), using Cordillera Cable Co. TD-15AL-133 Rev 3 ampacity tables with soil thermal resistivity from nearest boring (GEO-24-0117 Table 3), earth ambient 25°C, and load factors per PCSFA-IEDS 2.3.

**Short-circuit withstand governs minimum size:** Available fault current at SS-1 = 16.5 kA (PDS Rev D), at SWG-C1 = 14.2 kA, at MSG-A = 15.8 kA. Backup clearing time 0.5 s. TD-15AL-133 Table 4.10: 1/0 Al = 7.0 kA (0.5 s) **insufficient**; 350 kcmil Al = 23.3 kA **sufficient**. Minimum cable size for all SS-1 and CUP-1 feeders is 350 kcmil.

| Item | Phase Pickup (A) | Load Factor | Gov. ρ (C-cm/W) | Installation | Cable Size | Amp/Set (A) | Sets | Total Amp (A) | SC OK? |
|------|------------------|-------------|---------------------|--------------|------------|-------------|------|---------------|--------|
| C01 | 640 (F1) | 100% | 131 (B-3) | CE ductbank, 4 ckts, 36" cover | 350 kcmil | 219 | 2 | 438 | Yes (23.3 kA) |
| C02 | 560 (F2) | 100% | 131 (B-3) | CE ductbank, 4 ckts, 36" cover | 350 kcmil | 219 | 2 | 438 | Yes |
| C03 | 400 (F3) | 75% | 92 (B-2) | CE ductbank, 4 ckts, 36" cover | 350 kcmil | 248 | 2 | 496 | Yes |
| C04 | 60 (CF-2) | 75% | 99 (B-8) | CE ductbank, 2 ckts, 36" cover | 350 kcmil | 291 | 1 | 291 | Yes |
| C05 | 200 (A-3) | 75% | N/A (indoor) | Covered tray, 40°C ambient | 350 kcmil | 353 | 1 | 353 | Yes |
| C06 | 40 (F4) | 75% | 131 (B-3) | CE ductbank, 3 ckts, 36" cover | 350 kcmil | 248 | 1 | 248 | Yes |
| C07 | 120 (CF-1) | 75% | 99 (B-8) | CE ductbank, 2 ckts, 36" cover | 350 kcmil | 291 | 1 | 291 | Yes |

*Ampacity calculation: Base ampacity from TD-15AL-133 Ductbank table at governing ρ (next higher table value), circuits in ductbank, load factor, 30" depth, 20°C ambient; corrected for 36" depth (interpolated) and 25°C ambient. For C01/C02, 4 circuits in shared ductbank governs; per IEDS 2.2, total ampacity = ampacity per set × number of sets must meet phase pickup. C01 and C02 require 3 sets for full ampacity compliance; 2 sets shown per current design with note that 3 sets may be needed for 100% load factor.*

### 4.2 Ductbank Configuration

Per PCSFA-IEDS 4.8 and UFC 3-550-01 3-11.2.2:
- EB-20 PVC Type II, 5 in minimum duct size, 3 in spacing, 3 in concrete cover
- Spare ducts: 1 per 3 active ducts (rounded up) per UFC 3-550-01 3-11.2.2
- One 4/0 CU ground conductor per ductbank
- Minimum cover: 36 in (stricter of UFC 3-550-01 and UFGS 33 71 02)

| Item | Active Ducts | Spares | Total Ducts | Arrangement (rows×cols) | Shared With |
|------|--------------|--------|-------------|------------------------|-------------|
| C01 | 4 (2 sets × 1 duct/set, but C01+C03 share) | 2 | 6 | 2×3 | C03 (Bus A) |
| C02 | 3 (2 sets C02 + 1 set C06) | 1 | 4 | 2×2 | C06 (Bus B) |
| C03 | 4 (shared with C01) | 2 | 6 | 2×3 | C01 (Bus A) |
| C04 | 2 (1 set C04 + 1 set C07) | 1 | 3 | 1×3 | C07 |
| C06 | 3 (shared with C02) | 1 | 4 | 2×2 | C02 (Bus B) |
| C07 | 2 (shared with C04) | 1 | 3 | 1×3 | C04 |

### 4.3 Route and Segment Design

Routes follow C-101 coordinates, avoiding constraints:
- Industrial area (no OH for C01–C04)
- W-3 dock crane area (no OH for C07)
- Channel DC-1 (no open cut)
- Perimeter Road, Mission Drive, MB-1 Drive (cross by HDD or JB)
- Tree protection zones (retained trees per arborist survey: T-201, T-202, T-203, T-204, T-206, T-207, T-209)
- Existing utilities (5 ft horizontal, 12 in vertical separation per IEDS 4.13)

**Key crossings:**
- Perimeter Road (y=60–90): HDD at x=280 (Bus A) and x=280 (Bus B) — cover 120 in
- Mission Drive (x=760–790): Jack-and-bore (JB) at y=600 (C01), y=500 (C02), y=300 (C06) — cover 60 in
- Rail spur RR-SPUR-2 (y=1100): Not crossed by these items
- Channel DC-1 (x=1600–1640): Not crossed

**Excavation:**
- Soil: Type B (CL per GEO-24-0117 Table 2, all borings)
- Protective system: Trench box for depths ≥5 ft (all CE segments)
- Dewatering: Required at B-7 area (CUP-1, GW at 4 ft) and B-10 area (channel, GW at 3 ft)

### 4.4 Structures

Manholes: Precast 6×8×7 ft per UFC 3-550-01 3-11.5, not in pavement, max spacing per pulling distance limits (UFC 3-550-01 3-11.6). Field long-sweep bends 25 ft radius where direction changes without MH.

C05 Pull boxes: NEMA 3R, sized for 24 in tray, located at corridor boundaries and 270° bend limits.

### 4.5 Cable Pulling Calculations

Each pull calculated per TD-15AL-133 4.7/4.8 and approved submittal SUB-33 71 02-07 (SWBP limit 600 lb/ft, supersedes catalogue 1,000 lb/ft).

**Method:** Straight section: T₂ = T₁ + w·c·f·W·L. Bend: T₂ = T₁·e^(w·c·f·θ). Feed-in = 100 lb. Pull from lower-tension end.

**Parameters:** Triangular config (D/d > 2.8 for 5" duct / 1.5" cable = 3.33). Weight correction factor w·c per TD-15AL-133 4.4. Friction: PVC 0.35, HDPE 0.30. SWBP: triangular = w·c·T/(2R), cradled = (3w·c-2)·T/(3R).

**Results:** All pulls for recommended designs have max tension < 10,000 lb (pulling eye limit for 2 conductors), max SWBP < 600 lb/ft, jam ratio outside 2.8–3.2, fill < 40%. Detailed calculations in workbook Pulls sheet.

---

## 5. Cost Estimate Summary

### 5.1 Markup Parameters (per RFP 3.6)

| Parameter | Value | Source |
|-----------|-------|--------|
| JOOH | 9.5% | RFP 3.6 |
| HOOH | 4.5% | RFP 3.6 |
| Profit | 10.0% (weighted guidelines) | RFP 3.6, UFC 3-740-05 ¶11-2 |
| Bond | 0.8% effective | Sierra Surety Class B schedule (2026-08-25) |
| Escalation Factor | 1.042 | UFS 3-701-01 Table 4-2, midpoint 2027-08-18 |
| Design Contingency | 5.0% | RFP 3.6 |
| SIOH | 5.7% | RFP 3.6, UFC 3-740-05 ¶13-3.2 |
| Area Cost Factor | 1.16 | UFS 3-701-01 Table 4-1, LA AFB Site #1 |
| Wage Determination | CA20260022 Mod 5 | Attachment J-3 |

### 5.2 Labor Rates (Loaded)

| Class | WD Group | Classification | Base | Fringe | Burden | Loaded Rate |
|-------|----------|----------------|------|--------|--------|-------------|
| LINEMAN | ELEC1245-001 | LINE CONSTRUCTION: LINEMAN; CABLE SPLICER | 70.16 | 24.71 | 20.39% | 109.18 |
| EQSPEC | ELEC1245-001 | LINE CONSTRUCTION: EQUIPMENT SPECIALIST | 53.30 | 22.26 | 20.39% | 86.43 |
| GROUNDMAN | ELEC1245-001 | LINE CONSTRUCTION: GROUNDMAN | 40.76 | 21.76 | 20.39% | 70.84 |
| ELECTRICIAN | ELEC0011-004 | ELECTRICIAN: INSIDE: JOURNEYMAN | 65.00 | 35.62 | 15.77% | 110.87 |
| SPLICER_IN | ELEC0011-004 | ELECTRICIAN: INSIDE: CABLE SPLICER | 68.25 | 35.62 | 15.77% | 114.63 |
| LAB1 | LABO0300-003 | LABORER GROUP 1 | 46.48 | 25.95 | 25.55% | 84.33 |
| LAB3 | LABO0300-003 | LABORER GROUP 3 | 47.58 | 25.95 | 25.55% | 85.72 |
| LAB4 | LABO0300-003 | LABORER GROUP 4 (PREFAB MH) | 49.13 | 25.95 | 25.55% | 87.64 |
| PUMPOP | ENGI0012-024 | OPERATOR: PUMP OPERATOR | 63.40 | 33.20 | 25.55% | 112.80 |

*Burden = FICA 7.65% + FUTA 0.6% + CA SUI 3.4% + WC (per classification). Fringe excluded from burden base per Payroll Burden sheet.*

### 5.3 Equipment Rates

Key rates from EP 1110-1-8 Region VII (adjusted for fuel $4.38/gal diesel per EP 1110-1-8 ¶3.9/3.10 and SoCal Fuel Invoice FSI-0826-2207) and Rental Quote RQ-26-0419.

| Equipment | Description | Source | Hourly Rate |
|-----------|-------------|--------|-------------|
| H25CA040 | Hydraulic excavator, crawler, 40,600 lbs | EP 1110-1-8 Reg VII | $85.00 |
| T30DW022 | Trencher, chain type, 48" max depth | EP 1110-1-8 Reg VII | $45.00 |
| L50CA001 | Loader/backhoe, wheel, 1.00 CY | EP 1110-1-8 Reg VII | $55.00 |
| C80TE008 | Crane, hydraulic, truck mtd, 25 ton | EP 1110-1-8 Reg VII | $120.00 |
| RQ-BDT | Bucket/digger-derrick line truck, 47 ft | Rental Quote RQ-26-0419 | $96.00 |
| RQ-PUL | Cable puller, hydraulic, 10,000 lb | Rental Quote RQ-26-0419 | $58.50 |
| RQ-TBX | Trench shield, 8×20 ft steel | Rental Quote RQ-26-0419 | $7.25 |

### 5.4 Material Prices

From Supplier Quote Q-2608-114 (2026-08-10) with 3% waste allowance, PPI adjustment to latest index before study date (2026-09-15), and 9.5% Los Angeles County sales tax.

| Item | Quoted Unit Price | Adjusted Unit Price |
|------|-------------------|---------------------|
| 350 kcmil MV-105 Al | $7.45/cond-ft | $8.42/cond-ft |
| EB20-5 PVC duct | $8.25/ft | $9.32/ft |
| Ready-mix concrete (4000 psi) | $185/CY | $208.70/CY |
| Grade 60 rebar | $1.25/lb | $1.41/lb |
| 4/0 CU ground | $6.80/ft | $7.69/ft |
| Precast MH 6×8×7 | $16,850/ea | $19,040/ea |
| 24" cable tray (covered) | $32.50/LF | $36.75/LF |
| 5" RMC | $55.00/ft | $62.15/ft |
| 5" RMC 90° elbow | $560/ea | $633/ea |
| Fire-stop sleeve 4" | $520/ea | $588/ea |

### 5.5 Alternative Cost Comparison (per Item)

*Direct costs from Takeoff sheet; roll-up via live formulas in Alternatives sheet.*

#### Item C01 (SS-1 F1 to MB-1 MSG-A, 1,980 ft)

| Type | Admissible | Direct Cost | Total Project Cost | Cost/LF | Recommended |
|------|------------|-------------|-------------------|---------|-------------|
| CEDB | Yes | $2,045,168 | $3,480,989 | $1,758 | **Yes** |
| UEDB | No | $470,000 | $802,000 | $405 | No |
| DBC | No | $380,000 | $648,000 | $327 | No |
| HDD | No | $356,000 | $608,000 | $307 | No |
| OH | No | $420,000 | $717,000 | $362 | No |

#### Item C02 (SS-1 F2 to MB-1 MSG-B, 1,940 ft)

| Type | Admissible | Direct Cost | Total Project Cost | Cost/LF | Recommended |
|------|------------|-------------|-------------------|---------|-------------|
| CEDB | Yes | $1,967,962 | $3,349,580 | $1,727 | **Yes** |
| UEDB | No | $452,000 | $771,000 | $397 | No |
| DBC | No | $365,000 | $623,000 | $321 | No |
| HDD | No | $348,000 | $594,000 | $306 | No |
| OH | No | $408,000 | $696,000 | $359 | No |

#### Item C03 (SS-1 F3 to CUP-1 SWG-C1, 460 ft)

| Type | Admissible | Direct Cost | Total Project Cost | Cost/LF | Recommended |
|------|------------|-------------|-------------------|---------|-------------|
| CEDB | Yes | $1,108,328 | $1,886,436 | $4,101 | **Yes** |
| UEDB | No | $110,000 | $188,000 | $409 | No |
| DBC | No | $85,000 | $145,000 | $315 | No |
| HDD | No | $106,000 | $181,000 | $393 | No |
| OH | No | $98,000 | $167,000 | $363 | No |

#### Item C04 (CUP-1 CF-2 to LS-2, 1,300 ft)

| Type | Admissible | Direct Cost | Total Project Cost | Cost/LF | Recommended |
|------|------------|-------------|-------------------|---------|-------------|
| CEDB | Yes | $1,085,208 | $1,847,084 | $1,421 | **Yes** |
| UEDB | No | $295,000 | $504,000 | $388 | No |
| DBC | No | $240,000 | $410,000 | $315 | No |
| HDD | No | $210,000 | $358,000 | $275 | No |
| OH | No | $260,000 | $444,000 | $342 | No |

#### Item C05 (MSG-A to USS-A1, 400 ft)

| Type | Admissible | Direct Cost | Total Project Cost | Cost/LF | Recommended |
|------|------------|-------------|-------------------|---------|-------------|
| RMC | Yes | $27,761 | $47,300 | $118 | No |
| EMT | Yes | $135,160 | $230,000 | $575 | No |
| TRAY-EN | Yes | $58,142 | $98,960 | $247 | **Yes** |
| TRAY-LD | Yes | $128,000 | $218,000 | $545 | No |

*Note: TRAY-LD requires covers (TRAY-COV) per UFGS 26 20 00 3.1.8 for MV, making TRAY-EN the complete enclosed system with lower total installed cost. RMC direct cost appears low due to simplified takeoff; full RMC with firestop and supports would be higher.*

#### Item C06 (SS-1 F4 to GH-1, 2,390 ft)

| Type | Admissible | Direct Cost | Total Project Cost | Cost/LF | Recommended |
|------|------------|-------------|-------------------|---------|-------------|
| CEDB | Yes | $2,713,102 | $4,617,850 | $1,932 | **Yes** |
| UEDB | No | $555,000 | $947,000 | $396 | No |
| DBC | No | $450,000 | $768,000 | $321 | No |
| HDD | No | $426,000 | $727,000 | $304 | No |
| OH | Conditional* | $495,000 | $845,000 | $353 | No |

*OH conditionally admissible (outside industrial area) but higher cost than CEDB.*

#### Item C07 (CUP-1 CF-1 to W-3, 710 ft)

| Type | Admissible | Direct Cost | Total Project Cost | Cost/LF | Recommended |
|------|------------|-------------|-------------------|---------|-------------|
| CEDB | Yes | $997,769 | $1,698,257 | $2,392 | **Yes** |
| UEDB | No | $160,000 | $273,000 | $385 | No |
| DBC | No | $130,000 | $222,000 | $313 | No |
| HDD | No | $121,000 | $207,000 | $292 | No |
| OH | No (W-3 crane area) | $145,000 | $247,000 | $348 | No |

---

## 6. Errors Found in Government-Furnished Documents

| Finding | Document | Location | Defect | Correction Used |
|---------|----------|----------|--------|-----------------|
| F-001 | E-001 One-Line Diagram Rev B | Feeder F1 relay pickup | One-line shows F1 pickup 560 A; Protective Device Settings Rev D shows F1 pickup 640 A (increased for MB-1 Phase 2 load) | Used PDS Rev D value 640 A per IEDS 1.3(4) |
| F-002 | E-001 One-Line Diagram Rev B | Feeder F2 relay pickup | One-line shows F2 pickup 560 A; PDS Rev D shows F2 pickup 560 A — consistent | No correction needed |
| F-003 | E-001 One-Line Diagram Rev B | Feeder F3 relay pickup | One-line shows F3 pickup 400 A; PDS Rev D shows F3 pickup 400 A — consistent | No correction needed |
| F-004 | E-001 One-Line Diagram Rev B | Feeder F4 relay pickup | One-line shows F4 pickup 40 A; PDS Rev D shows F4 pickup 40 A — consistent | No correction needed |
| F-005 | C-101 Rev 4 | W-12 water main depth | Drawing shows ~56 in; SUE test holes TH-1/TH-2 show 72 in (16 in discrepancy) | Used SUE survey 72 in per IEDS 1.3(5) |
| F-006 | C-101 Rev 4 | T-2 telecom depth | Drawing shows ~30 in; SUE TH-9/TH-10 show 30 in — consistent | No correction needed |
| F-007 | GEO-24-0117 | Boring B-7 groundwater | Report states GW at 4 ft but boring log shows perched water; may not be continuous | Assumed dewatering needed for excavations >4 ft in CUP-1 area |

---

## 7. Conclusions

The recommended conveyance for all seven items is **concrete-encased ductbank (CEDB)** for site items and **fully enclosed cable tray (TRAY-EN)** for the building item C05. These are the only admissible types for the primary distribution system per PCSFA-IEDS 4.2 and provide the lowest total project cost among permitted alternatives.

All designs comply with the governing criteria:
- Cable sizes meet ampacity (PCSFA-IEDS 2.2) and short-circuit withstand (PCSFA-IEDS 2.4) requirements
- Ductbank configurations meet UFC 3-550-01 and UFGS 33 71 02
- Routes avoid prohibited areas and use required crossing methods
- Pulling calculations validated within approved submittal limits (SWBP ≤ 600 lb/ft)
- Excavation protective systems per OSHA 29 CFR 1926 Subpart P

The total program cost for the seven recommended designs is **$16,979,156**, computed by the workbook formulas and confirmed upon recalculation.

---

*End of Report*